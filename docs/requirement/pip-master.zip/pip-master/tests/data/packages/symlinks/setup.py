from setuptools import setup

version = '0.1'

setup(name='symlinks',
      version=version,
      packages=["symlinks"],
      )
