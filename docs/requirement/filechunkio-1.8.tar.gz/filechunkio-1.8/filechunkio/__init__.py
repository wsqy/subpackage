from __future__ import absolute_import

from .filechunkio import FileChunkIO


__version__ = VERSION = 1.8
