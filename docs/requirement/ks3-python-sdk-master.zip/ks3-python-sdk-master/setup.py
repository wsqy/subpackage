import os
from setuptools import setup

setup(
    name = "ks3sdk",
    version = "1.0.0",
    author = "ksc",
    description = (""),
    license = "BSD",
    #url = "http://packages.python.org/an_example_pypi_project",
    packages=['ks3']
)
