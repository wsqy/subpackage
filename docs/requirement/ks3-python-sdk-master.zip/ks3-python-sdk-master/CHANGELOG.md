
v1.0.1/2016-03-02
    删除默认Host设置
    增加get_bucket_location接口